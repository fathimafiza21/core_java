package com.cg.springioc;

public interface Sim {
	void calling();
	void data();
}
