package com.cg.springioc;

public class Airtel implements Sim{
	public void calling() {
		System.out.println("Calling using Airtel Sim");		
	}

	public void data() {
		System.out.println("Browsig data using Airtel Sim");		
	}
}
