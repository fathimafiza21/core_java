package com.cg.springioc;

public class Jio implements Sim {

	public void calling() {
		System.out.println("Calling using Jio Sim");
	}

	public void data() {
		System.out.println("Browsing data using Jio Sim");
	}

}
