package com.tnsif.dayfive.hierarchicalinheritance;

public class LightMotorVehicle {

}
