package com.tns.springioc;

public class Airtel implements Sim{

	public void calling() {
	System.out.println("Calling through Airtel Sim");
		
	}

	public void data() {
	System.out.println("Airtel Data used for browsing ");
	}
	

}
