package com.tns.springioc;

public class Jio implements Sim {

	public void calling() {
		System.out.println("calling through Jio sim");
		
	}

	public void data() {
		System.out.println("Jio Data used for Browsing ");
		
	}

}
