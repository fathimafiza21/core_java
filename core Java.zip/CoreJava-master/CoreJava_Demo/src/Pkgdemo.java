

//import java.lang.Math;

import static java.lang.Math.*;

public class Pkgdemo
{
	

	public static void main(String[] args) {
		int no=9;
		System.out.println(sqrt(no));
	//	System.out.println(Math.sqrt(no));
		
		
	}

}
