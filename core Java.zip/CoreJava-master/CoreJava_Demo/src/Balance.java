

public class Balance { //public

	String name; //default
	private int bal; //default
	public Balance() //constructor
	{
		name="Amit";
		bal=65000;
	}
	public void show()
	{
		System.out.println("Name : "+name+"\tBalance : "+bal);
	}
}
