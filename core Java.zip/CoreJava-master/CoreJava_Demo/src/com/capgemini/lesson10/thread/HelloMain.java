package com.capgemini.lesson10.thread;

public class HelloMain {

	public static void main(String[] args) {
		
		
		HelloThread hello = new HelloThread();
		hello.start();

	}

}
