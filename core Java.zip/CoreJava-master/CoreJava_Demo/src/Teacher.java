

//Teacher is a subclass of Person
public class Teacher extends Person
{
	String batch;
	String subjects;
	public String getBatch() {
		return batch;
	}
	public void setBatch(String batch) {
		this.batch = batch;
	}
	public String getSubjects() {
		return subjects;
	}
	public void setSubjects(String subjects) {
		this.subjects = subjects;
	}
	public void show()
	{
		super.city="Mumbai";
	}
	
}
