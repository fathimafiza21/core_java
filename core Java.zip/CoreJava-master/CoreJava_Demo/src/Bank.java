
public interface Bank 
{
	void showBalance();
	void deposit(int amt);
	void withdraw(int amt);
}
