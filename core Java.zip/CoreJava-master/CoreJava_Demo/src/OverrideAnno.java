

class Employee 
{
	@Override
	public String toString() 
	{
		return "Employee [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	
}

public class OverrideAnno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
