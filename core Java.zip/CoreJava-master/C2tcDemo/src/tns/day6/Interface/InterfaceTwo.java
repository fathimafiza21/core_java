package tns.day6.Interface;

public interface InterfaceTwo {
	void display();
}
