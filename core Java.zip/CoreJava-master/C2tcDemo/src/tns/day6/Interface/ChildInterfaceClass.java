package tns.day6.Interface;

public class ChildInterfaceClass implements InterfaceOne {

	@Override
	public void show() {
		System.out.println("In Interface implemented method ");

	}
}
