package tns.day6.finalkeyword;

public class FinalClassDemo {

	public static void main(String[] args) {
		FinalClass f1=new FinalClass();
		f1.show();
	}

}
