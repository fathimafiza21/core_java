package tns.day6.finalkeyword;

public final class FinalClass {
	public final void show()
	{
		System.out.println("Within Final Method of Final Class");
	}
}

//cannot create child class from final class 
/*
 * class A extends FinalClass {
 * 
 * }
 */
