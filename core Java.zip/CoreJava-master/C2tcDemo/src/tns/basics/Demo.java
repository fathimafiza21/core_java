package tns.basics;

public class Demo {
	public static void main(String[] args) {
		int a, b ;
		a = 10;
		b = 60;
	//int c;
		System.out.println("Welcome to Core Java 8");
		System.out.println("Streamapi, collections");
		System.out.println("Addition is "+(a + b));
	}
}
