package tns.day3;

public class PersonDemo {
	public static void main(String[] args) {
		Person p1=new Person();
		p1.getData();
		p1.show();
		
		Person p2=new Person();
		//p2.accept("Parth", "Mumbai");
		p2.show();
	}

}
